#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

#define TESTALLOCSIZE 8
#define NTEST 1000

struct test{
	char data[TESTALLOCSIZE];
};

void slabtest(){
	#if 0
	int i;
	struct test *t[NTEST];

	slabdump();

	cprintf("1\n");
	for(i=0;i<NTEST;i++){
		t[i] = (struct test *)kmalloc(sizeof(struct test));
	}

	slabdump();
	
	cprintf("2\n");
	for(i=NTEST-1;i>=0;i--){
		kmfree((char *)t[i], TESTALLOCSIZE);
	}

	slabdump();
	#endif
}

int sys_slabtest(){
	slabtest();
	return 0;
}
